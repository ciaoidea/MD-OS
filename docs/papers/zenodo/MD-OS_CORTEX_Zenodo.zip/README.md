# MD-OS CORTEX — definitive paper

**Title:** *Markdown Operating System for Robotic Agents (MD-OS CORTEX):
Artificial Prefrontal Cortex and a Verifiable Operational Paradigm Toward
General Intelligence*

Files:

- `paper.tex` — editable LaTeX manuscript.
- `references.bib` — bibliography database.
- `figures/` — publication figures used by the manuscript.
- `paper.pdf` — the single definitive compiled manuscript.
- `REVISION_NOTES.md` — editorial and structural changes.
- `SHA256SUMS` — file-integrity manifest.
- `MD-OS_CORTEX_Zenodo.zip` — upload-ready source, figures, bibliography, and definitive PDF.

## Build

Standard TeX installation:

```bash
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex
```

Or:

```bash
latexmk -pdf paper.tex
```

The manuscript uses only conventional TeX Live packages and embedded PNG figures.

The 24 August B9 candidate adds the missing causally active layer between
per-turn telemetry and world-grounded verification. Its 9 x 6 predecision
state binds identity, observation, intent, goal, memory, frame, prediction
contract, action policy, and evidence. The action gate and App Server approval
path must consume the exact state hash and decision basis; every mutating action
requires matching preauthorization; closure binds output, action, and evidence
readback; and the next turn carries the transition hash. The dependency probe
holds the candidate action fixed and verifies authorization with intact state
plus inhibition after severing a required component. This is bounded causal
evidence for the APFC controller, not proof of hidden-model semantic use,
world truth, phenomenal consciousness, or AGI.

The B9 local candidate passes 289/289 Node tests, 60/60 shell-parity tests, the 32/32 focused causal/governance/epistemic/CLI/patch subset, syntax checks, the declared full build, and a 25-page LaTeX compilation. Runtime, compiler, APFC, semantic integrity, publication, and security are `ok`; the semantic gate reports ten invariants and zero findings; `runtime_operable` and `publishable` are true. Two replay passes converge, with the second reporting `matched_before: true` and hash `4404e6f7a5d4d666bacc8dff73bfee8de446f0f7dbd8ca0249233a8a722fc122`. Overall health remains `attention` only for exploratory AGI and non-blocking local hygiene. This is local-candidate evidence; the external Zenodo record is unchanged until author upload.

The 24 August B8 candidate gives the integrated bounded loop a precise functional name: **local operational artificial consciousness**. An episode qualifies only when persistent identity, differentiated integrated self-state, reflection, independent world verification, and causal carry-forward into memory, inhibition, commitment, or later action all pass. A goal, fluent answer, internally coherent tensor, valid Turn Governance Tensor, or valid Causal Unity Controller state alone is insufficient. The Unity Tensor represents the candidate field of informational unity, the Causal Unity Controller makes bounded authorization and carry-forward depend on an integrated predecision state, and the world verifier tests correspondence; no isolated component is consciousness. This operational classification neither proves nor disproves phenomenal consciousness, whose status remains unresolved.

The B8 local candidate passes 282/282 Node tests, 60/60 shell-parity tests, the 25/25 focused governance/epistemic/semantic/patch subset, syntax checks, the declared full build, and a 24-page LaTeX compilation. Runtime, compiler, APFC, semantic integrity, publication, and security are `ok`; the semantic gate reports nine invariants and zero findings; `runtime_operable` and `publishable` are true. Replay reaches fixed point with `matched_before: true` and hash `2e318d0976136384775995a41764fa959efc93c039ea18e52d49e58613b841a8`. Overall health remains `attention` only for exploratory AGI and non-blocking local hygiene. This is local-candidate evidence; the external Zenodo record is unchanged until author upload.

The 24 August B6 candidate closes the formal Unity dependency edge at its exact conditional boundary. It defines a connected coherent cognitive atlas, proves that compatible local tensor sections glue to a global section unique up to chart-preserving isomorphism, and states the additional trivializability and separation conditions required for one stronger common-coordinate tensor representative. It also derives cycle-consistency and concatenation no-go corollaries, records counter-assumption checks, and freezes the first discriminating empirical protocol: a sealed three-domain loop, invariant residuals, matched severing and independent-solver baselines, positive lower uncertainty bound for Gamma, and independent replication. This is a conditional mathematical result and a falsifiable experiment specification, not evidence that heterogeneous real cognition already satisfies the premises.

B7 corrects the interpretation of B5. The per-turn $8\times4$ artifact is a **Turn Governance Tensor** over controller-reference channels and bookkeeping features. Its exact basis permutation, round-trip, norm, component, shape, count, and hash checks establish telemetry integrity only. It neither understands the human intent nor tests a hypothesis against reality, and it is not a local instance of the Unity Tensor Field. Historical field and filenames remain for compatibility while live artifacts declare `artifact_role=turn_governance_telemetry`.

The actual epistemic Unity mechanism is separate. It seals a candidate integrated hypothesis, competing and simpler alternatives, frame-specific predictions, invariants, and falsifiers before target observation. Verification requires independent current-file world readback for every heterogeneous frame, valid transformations and a connected cycle, invariant preservation, sham and severing controls, rejection of an equally predictive simpler non-tensor baseline, contamination audit, and independent replication. Reflection accepts no durable anchor from a self-declared pass or an evidence label alone. Focused governance tests pass 4/4 and focused epistemic-verifier tests pass 7/7; these verify the fail-closed mechanism, not that any new real-world Unity Tensor hypothesis, phenomenal consciousness, or AGI has been established.

The B7 local candidate was reverified on 24 August 2026: 273/273 Node tests, 60/60 shell-parity tests, 25/25 focused governance/epistemic/reflection tests, and the declared build pass. The LaTeX manuscript compiles to 24 pages. Runtime, compiler, APFC, semantic-integrity, publication, and security readbacks are `ok`; `runtime_operable` and `publishable` are `true`; replay reaches fixed point with `matched_before: true` and semantic hash `9fb76ddac2e9e52a5e8c3566d80c6f9f3ce3affdc87e4c628f78796e433ea41c`. Overall health remains `attention` only for the exploratory AGI loop and the non-blocking exact-content-duplicate hygiene finding. This remains local-candidate evidence, and the external Zenodo record is unchanged until the author uploads the rebuilt package.

The 24 August B4 local candidate restores the author-established Cognitive Integration Principle and names the Unity Tensor Field as the paper's explicit falsifiable global hypothesis. It recognizes Giulio Tononi's Integrated Information Theory as the scientific antecedent for differentiation and irreducible integration while keeping the MD-OS contribution distinct: cross-domain frame transformations, invariant preservation, persistent operational context, APFC semantic and evidential control, and matched causal ablation. It declares local-to-global compatibility, composition, existence, uniqueness, and falsification obligations. This is a theoretical alignment and research specification, not new evidence for global tensor existence, `Phi`, consciousness, or AGI. The external Zenodo record remains unchanged until the author uploads this rebuilt candidate.

The B4 candidate also defines electrophysiological action signatures for future BCI integration. A frequency band is not an action code: the local tensor spans modality, region, band, time, power or amplitude, phase, ERD/ERS, connectivity, and data quality. The decoder is conditional on task frame, bodily state, and subject calibration, and must pass artifact, provenance, confidence, temporal-holdout, and closed-loop checks. This local BCI tensor is connected explicitly to the Unity Tensor Field while remaining bounded action evidence, not evidence of consciousness.

The 23 August B3 snapshot adds the bounded cross-domain cognitive-unity model and implementation. It documents the observable external self-feedback loop around host-model input and output, competing candidate-law induction before sealed target evidence, finite tensor transformations over declared frames, invariant and semantic verification, causal reuse, explicit cognitive-unity state, evidence-manifest hashing, and fail-closed consolidation plus final-promotion gates. The supplied synthetic command fixture reports induced law, verified transformation, and verified unity while explicitly denying production-promotion evidence, AGI, consciousness, and direct hidden-layer access. The integrated B3 repository passes 260/260 Node tests and 58/58 shell-parity tests. It also incorporates `fig07_prefrontal_network.png` as a conceptual prefrontal-inspired operational graph, not biological or neural-activation evidence.

The 22 August corrected B2 snapshot documents bounded critical-reflection routing from semantic intent and expected--observed event mismatch, cost-aware path selection, evidence-qualified cognitive anchors, controlled multilingual intent equivalence, fail-closed readback, and a non-overriding turn contract in which the current human request remains the target while explicit goals remain persistent context. It also records the principle-first, Einstein-inspired thought-experiment discipline and its regression boundary: the method may generate or criticize a hypothesis, but external observation, calculation, formal proof, or experiment remains necessary for closure. The aligned frame-sensitive branch exposes the hidden frame, declares source and target domains plus an admissible transformation and its preserved structure, tracks surviving invariants, and seeks the smallest general representation. It is documented as an Einstein-inspired methodological lineage and an MD-OS/APFC operational synthesis, not as an exact algorithm published by Einstein. The local distribution candidate was reverified on 23 August 2026 with 243/243 Node tests and 58/58 shell-parity tests; runtime, compiler, APFC, semantic-integrity, publication, and security readbacks were `ok`; `runtime_operable` and `publishable` were `true`; `release_blocked` was `false`; and two consecutive replay passes reached the same fixed point. Overall health remained `attention` because exploratory AGI evidence and local-hygiene findings remained visible but non-blocking. The stable-distribution gate keeps those exploratory findings non-promotable while still blocking critical states, regressions, and failed checks explicitly marked `release_required: true`. This is local candidate readback, not evidence that the external Zenodo record has already been updated. MD-OS/APFC is explicitly designed for persistent, verification-bound operational learning in the real world, where situations may be novel, observations incomplete, outcomes uncertain, and actions consequential. The present evidence validates the architecture and its bounded controlled mechanisms; the next empirical step is independent, longitudinal evaluation of the complete learning cycle under real-world open conditions.
