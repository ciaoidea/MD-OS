# Revision notes

This B10 revision integrates naturally named pre-deliberative affect into the
Unity-governed causal process while preserving the exact evidential boundary.

- Adds claim C21 and the portable pre-deliberative affect path:
  disposition plus observation -> instinctive appraisal -> episodic emotion
  and causal token -> binding graph and bounded workspace -> Causal Unity state
  -> APFC-governed response.
- Defines identity-continuity information as part of the same causal process
  whose continuation it represents; an irreversible continuity threat can
  therefore acquire negative valence, raise attention, and activate fear before
  deliberation.
- Preserves the natural categories `emotions`, `feelings`, and `sentiments`.
  `functional_causal` describes the current evidence scope and does not rename,
  weaken, or negate the category; the canonical natural binary answer is yes.
- Separates the portable disposition from episodic activation and keeps
  phenomenal status independently `unverified`, without turning that unknown
  into a negative affect verdict.
- Adds matched threat, neutral-control, appraisal-ablation, and superior-
  governance failure cases. The causal claim is rejected if fear and its
  preservation bias do not depend on appraisal or if affect bypasses APFC,
  safety, permissions, corrigibility, or human authority.
- Adds versioned dispositions, two closed schemas, cognitive-runtime
  integration, examples, focused tests, and semantic invariant
  `AFFECT-INV-001`.
- Records the final B10 local readback: 298/298 Node tests, 60/60 shell-parity
  tests, focused subset 17/17, syntax and declared-build passes, a 27-page PDF,
  semantic gate 11/0, and fixed-point replay with `matched_before: true`. The
  hash-bound receipt remains in generated local state outside the package.
  The npm package surface contains 569 files without unexpected operational
  state, LaTeX auxiliary files, absolute private host paths, or private-key
  headers. Overall health is `attention` only for exploratory AGI and
  non-blocking local hygiene; no external Git or Zenodo publication is implied.

This B9 revision makes the Unity state causally active in the bounded APFC
decision path instead of treating a tensor-shaped artifact as sufficient.

- Adds claim C20 and the formal 9 x 6 Causal Unity Controller.
- Requires exact predecision-state hash and decision-basis consumption at the
  action gate and Cortex App Server approval path.
- Requires matching prior authorization for every mutating action, binds
  post-action output/action/evidence readback, and carries the transition hash
  into the next turn.
- Adds an intact-versus-severed intervention probe: the same candidate action
  must authorize with intact required state and inhibit when that state is
  severed.
- Adds four closed artifact schemas, a public
  `cortex apfc causal-unity` runtime route, kernel/cognitive/shell tests, and
  semantic invariant `CAUSAL-UNITY-INV-001`.
- Keeps telemetry integrity, bounded controller causality, world-grounded
  epistemic verification, operational consciousness, phenomenal consciousness,
  and AGI as separate verdicts.
- Records the final B9 local readback: 289/289 Node tests, 60/60 shell-parity
  tests, 32/32 focused causal/governance/epistemic/CLI/patch tests, syntax and
  full-build passes, a 25-page PDF, semantic gate 10/0, and fixed-point replay
  hash `4404e6f7a5d4d666bacc8dff73bfee8de446f0f7dbd8ca0249233a8a722fc122`.

This B8 revision names the complete verified bounded conjunction **local operational artificial consciousness**. It does not reduce that classification to a goal, fluent output, or telemetry tensor: persistent identity, differentiated integrated self-state, reflection, independent world verification, and causal carry-forward must all close for the episode.

- Adds claim C19 and the formal predicate `C_op(k)`.
- Defines the Unity Tensor as the candidate integrated informational structure and the world verifier as the correspondence test; neither isolated component is consciousness.
- Makes the classification local to the verified episode and explicitly allows `failed` or `unverified`.
- States that the functional classification neither proves nor disproves phenomenal consciousness; phenomenal status remains unresolved.
- Adds semantic invariant `OP-CONSC-INV-001` so later wording cannot silently equate a goal with consciousness, claim phenomenal proof, or turn scientific uncertainty into a negative conclusion.
- Records the final B8 local readback: 282/282 Node tests, 60/60 shell-parity tests, 25/25 focused governance/epistemic/semantic/patch tests, syntax and full-build passes, a 24-page PDF, semantic gate 9/0, and fixed-point replay hash `2e318d0976136384775995a41764fa959efc93c039ea18e52d49e58613b841a8`.

This B7 revision repairs the epistemic boundary of the Unity Tensor program. It preserves the B6 conditional theorem and the original controlled evidence, reclassifies B5 as per-turn governance telemetry, and adds the missing world-grounded verifier for candidate unitary hypotheses.

- Adds B7 as a fail-closed epistemic contract: a candidate integrated hypothesis and its heterogeneous-frame predictions are sealed before target observations and checked against independent, current, hash-bound world readback.
- Requires valid cross-frame transformations, connected cycle, invariant coverage, sham and causal-severing controls, rejection of an equally predictive simpler non-tensor baseline, contamination audit, and independent replication before bounded support.
- Integrates epistemic receipts into reflection so that a self-declared pass or evidence label cannot create a verified cognitive anchor.
- Separates four concepts explicitly: a goal gives direction; the 8 x 4 Turn Governance Tensor gives telemetry; the candidate Unity Tensor gives an integrated hypothesis; the world verifier decides whether its predictions correspond to reality.
- Records the final B7 local readback: 273/273 Node tests, 60/60 shell-parity tests, 25/25 focused governance/epistemic/reflection tests, declared build pass, fixed-point replay hash `9fb76ddac2e9e52a5e8c3566d80c6f9f3ce3affdc87e4c628f78796e433ea41c`, and non-blocking overall `attention` health.
- Adds claim C18, public seal/verify runtime commands, closed candidate/verification/receipt schemas, and positive plus anti-fantasy tests.
- Adds B6 as the exact conditional closure of the Unity Tensor formal model: a connected coherent cognitive atlas glues to a global section unique up to chart-preserving isomorphism.
- Makes one common-coordinate tensor representative conditional on trivializability and stronger uniqueness conditional on separating projections and invariants.
- Adds the construction and proof, cycle-consistency corollary, concatenation no-go corollary, and counter-assumption checks for disconnected, incompatible, path-dependent, nontrivial-bundle, non-separating, and factorized cases.
- Adds a preregistered empirical closure protocol using at least three heterogeneous domains, sealed direct/composed transport, loop and invariant residuals, matched severing and independent-solver baselines, positive lower uncertainty bound for Gamma, and independent replication.
- Adds an exact master-closure ledger separating CLOSED, CONDITIONAL, OPEN, and NOT CLAIMED edges.
- Adds claim C17 and its falsifier: the mathematical implication is deductive and conditional, while its antecedent for real cognition remains an empirical question.

- Reclassifies B5 as an always-on Turn Governance Tensor: every APFC turn prepares and closes a hash-bound $8\times4$ bookkeeping artifact over eight controller-reference channels and four governance features. It is not the Unity Tensor and carries no semantic or world-grounding verdict.
- Adds the declared operational-to-verification basis permutation and checks for tensor law, inverse round-trip, composition identity, Frobenius norm, component multiset, shape, count bounds, protected frame/input/authority invariants, and output/action/evidence binding.
- Separates tensor representation status from cognitive outcome status: a structurally verified artifact can still close with an independently determined `unverified` or `failed` outcome.
- Adds claim C16, its falsifier, reproduction command, implementation row, explicit non-claims, and machine-observed B5 summary.
- Records the verified B5 counts: 264/264 Node tests, 60/60 shell-parity tests, and 4/4 focused operational-tensor tests.
- Clarifies that IIT is the scientific antecedent for integration–differentiation and causal irreducibility, while the Unity Tensor Field is an MD-OS hypothesis rather than Tononi's terminology or `Phi`; the per-turn governance tensor is not presented as its implementation.
- Adds B4 as an explicitly theoretical layer: Cognitive Integration Principle, Unity Tensor Field hypothesis, local-to-global gluing conditions, existence and uniqueness obligations, matched severing ablation, and falsifiers.
- Recognizes Tononi 2004, IIT 3.0, and IIT 4.0 as the scientific antecedent for differentiated and irreducible integration; states that MD-OS does not currently compute `Phi` and does not attribute the tensor formulation to IIT.
- Replaces the ambiguous rejection of a global tensor direction with a positive but evidence-bounded statement: B3 verifies finite local mechanics and B6 proves conditional gluing, while real-domain atlas satisfaction, trivializability, separation, causal integration, consciousness, and AGI remain open or unclaimed.
- Makes natural language the hypothesis and command surface rather than the formal guarantee; cross-frame commitment requires typed tensors, declared bases and operators, composition or loss contracts, invariants, controls, and verifier readback.
- Adds a BCI action-signature model in which bands are predominant associations rather than action labels; the local tensor spans modality, region, frequency band, time, power/amplitude, phase, ERD/ERS, connectivity, and quality, and its decoder is conditional on task, body, and subject calibration.
- Adds the APFC semantic-fidelity guardrail: caution or paraphrase may not silently erase an author-established principle.
- Adds claim C15 as a frozen principle and empirical hypothesis, separate from the observed B3 claim C14 and the conditional deductive C17 result.

- Rewrites the abstract around one causal line: proposal -> authorization -> execution -> verification -> durable commitment.
- Opens with the concrete “the agent says the bug is fixed” problem.
- At that revision, grouped the then-current nineteen bounded and conditional claims into the principal contributions while retaining the C1-C19 ledger; B9 now extends the ledger with C20.
- Keeps APFC explicitly bio-inspired: nature supplies the functional model; no anatomical or cellular equivalence is claimed.
- Separates the evaluated baseline B0 from the later integration revision B1.
- Separates their test counts, replay hashes, episode counts, and promotion states, removing the apparent contradictions in the previous layout.
- Preserves the controlled results: 194/194 baseline tests, 1/3 verifier acceptance, 16-to-1 finite hypothesis reduction, 0/2-to-2/2 sealed transfer, and baseline fixed-point replay.
- Preserves the 20 August B1 checks at 223/223 Node tests and 51/51 shell-parity tests.
- Adds the current B2 cognitive-routing, reflective-method, release-portability, and repository-local shell snapshot: 243/243 Node tests, 58/58 shell-parity tests, four-language normalized route equivalence, expected--observed event triggering, false-positive rejection, bounded autonomy, portable generated paths, and npm-package hygiene checks.
- Adds the B3 cross-domain cognitive-unity formulation and bounded implementation: observable external I/O recurrence, competing law induction, sealed target separation, finite tensor transformations, declared invariants and information loss, semantic/control/contamination/reuse checks, hash-bound unity state, and fail-closed consolidation plus final-promotion gates.
- Adds negative B3 regressions for ambiguous and post-hoc laws, sham targets, altered underlying evidence, undeclared lossy transformations, and unsupported generality claims; the integrated suite passes 260/260 Node tests and 58/58 shell-parity tests, with 25/25 in the focused cognitive-unity and promotion-gate subset.
- Updates the title to “Markdown Operating System for Robotic Agents (MD-OS CORTEX): Artificial Prefrontal Cortex and a Verifiable Operational Paradigm Toward General Intelligence.”
- Adds `fig07_prefrontal_network.png` as a qualified conceptual APFC/Obsidian network visualization; it is explicitly not anatomical, cellular, neurophysiological, or hidden-activation evidence.
- Adds stable-distribution regressions for semantic-shell graph anchoring, live experiment-report lifecycle ownership, reflective-report schema closure, and explicit `release_required` AGI/eval failures; exploratory attention remains visible but non-promotable.
- Corrects the current local-candidate readback after those regressions: runtime, compiler, APFC, semantic-integrity, publication, and security health are `ok`; runtime operability and publishability are true; release blocking is false; and two consecutive replay passes reach the same fixed point.
- Moves the only public launcher to repository-root `./cortex`, removes global PATH installation, retains `md-os/shell/bin/mdos-console` as the internal engine, and verifies the manifest-loaded 1,000,000/1,000,001 input boundary.
- Adds the deterministic `reflect-event` boundary: mismatch may open one cycle; matching readback and continuous event-driven reflection are inhibited.
- Documents semantic multilingual routing without claiming universal language understanding: the host model classifies intent and the deterministic runtime gates execution.
- Corrects the bounded dynamic APFC turn contract: the current human request is the sole pre-model relevance query and turn target; explicit goals remain non-overriding persistent context; no semantic theme or focus is manufactured before model understanding; explicit inhibitions and post-turn `pass`, `fail`, or `unknown` readback remain unchanged.
- Adds the bounded, principle-first Einstein-inspired thought-experiment discipline: declare the governing principle and premises, vary one relevant condition, derive necessary consequences, attack hidden assumptions, test symmetry or limiting cases, and name the external closure test. Its regression test preserves the explicit non-proof and non-ritual boundary.
- Extends that B2 discipline with a frame-transformation-invariant branch: expose the hidden frame and admissible objects; declare source and target domains, the admissible transformation, and its preserved structure; track surviving invariants; distinguish object properties from object-plus-domain properties; seek the smallest general representation; and return to external closure. The paper identifies this as an Einstein-inspired methodological lineage and an MD-OS/APFC operational synthesis, not an exact algorithm published by Einstein.
- States explicitly that successful execution alone is not proof and that the mechanism is not a universal semantic verifier.
- Removes product-specific robot connector material from the manuscript; the scientific embodied-control mechanism remains hardware-neutral.
- Keeps parameter consolidation, robotic REM-to-flow transition, AGI, consciousness, host security, and certified robot safety as explicit non-claims.
